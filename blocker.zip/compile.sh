/home/x/Programming/fpc/lib/fpc/3.0.0/ppcx64 -CX -XX -Fl/usr/lib/gcc/x86_64-linux-gnu/4.8/ -Fl/usr/lib/i386-linux-gnu/ -Fl/usr/lib/x86_64-linux-gnu/ -Fu./mlib -Fi./mlib -Fu./lnet -Fi./lnet $1
#/home/x/Programming/fpc/lib/fpc/3.0.0/ppcx64 -CX -XX -Fl/usr/lib/gcc/x86_64-linux-gnu/4.8/ -Fl/usr/lib/i386-linux-gnu/ -Fl/usr/lib/x86_64-linux-gnu/ -Fu./mlib -Fi./mlib -Fu./lnet -Fi./lnet $1
#-Fu/usr/lib/fpc/$fpcversion/units/i386-linux/fcl-base/
#-Fu/home/x/Programming/lazarus/lcl/
#-Fu/home/x/Programming/Components/acb/trunk/ACBrComum/ -Fu/home/x/Programming/lazarus/components/lazutils/
#-Fu/usr/share/fpcsrc/2.6.2/packages/fcl-base/units/i386-linux/
#-Fi/home/x/Programming/Projects/mylibrary/units/
#-Fi/home/x/Programming/lazarus/lcl/include/
#-CX -XX -Tlinux -Pi386
#-Fi~/Various/mystic_sourcecode/mystic/
#$/home/x/Programming/fpc/bin/fpc
