#!/bin/bash
./cp437 ./blocker
